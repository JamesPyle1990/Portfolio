from flask import Flask, jsonify, request
import db

app = Flask(__name__)

# Flask Test
@app.route('/test')
def RestAPI():
    return "Rest API!"




#Method to get all names in the mongo database
@app.route('/get', methods=['GET'])
def get_all_names():
    nameList = db.db.collection 

    output = []

    for q in nameList.find():
        output.append({'name' : q['name']})
    
    return jsonify({'result' : output})




#Method to post a new name and return it from the mongo database
@app.route('/post', methods=['POST'])
def add_names():
    nameList = db.db.collection

    name = request.json['name' ]

    name_id = nameList.insert({'name' : name})
    new_name = nameList.find_one({'_id' : name_id})

    output = {'name' : new_name['name']}

    return jsonify({'result' : output})

    



if __name__ == '__main__':
    app.run(port=8000)