from flask import Flask, jsonify, request
from flask_pymongo import pymongo
from app import app


CONNECTION_STRING = "mongodb+srv://James:Sanitarium1@cluster0.nmxr4.mongodb.net/RestAPI?retryWrites=true&w=majority"
client = pymongo.MongoClient(CONNECTION_STRING)


db = client.get_database('RestAPI')
user_collection = pymongo.collection.Collection(db, 'test')