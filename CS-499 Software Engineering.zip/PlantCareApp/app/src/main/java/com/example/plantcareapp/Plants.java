package com.example.plantcareapp;

public class Plants {
    private int id;
    private String name;
    private String schedule;
    private String imageURL;

    public Plants(int id, String name, String schedule, String imageURL) {
        this.id = id;
        this.name = name;
        this.schedule = schedule;
        this.imageURL = imageURL;
    }

    @Override
    public String toString() {
        return "Plants{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", schedule=" + schedule +
                ", imageURL='" + imageURL + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSchedule() {
        return schedule;
    }

    public void setSchedule(String schedule) {
        this.schedule = schedule;
    }

    public String getImageURL() {
        return imageURL;
    }

    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }
}


