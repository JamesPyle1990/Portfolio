package com.example.plantcareapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.List;

public class AddEditOne extends AppCompatActivity {

    Button btn_ok, btn_cancel;
    List<Plants> plantsList;
    EditText et_Plant_name, et_schedule, et_imageUrl;
    TextView tv_plantId;
    int id;



    MyApplication myApplication = (MyApplication) this.getApplication();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_one);

        plantsList = myApplication.getPlantsList();

        btn_ok = findViewById(R.id.btn_ok);
        btn_cancel = findViewById(R.id.btn_cancel);
        et_Plant_name = findViewById(R.id.et_PlantName);
        et_schedule = findViewById(R.id.et_schedule);
        et_imageUrl = findViewById(R.id.et_imageUrl);
        tv_plantId = findViewById(R.id.tv_plantIdNumber);

        Intent intent = getIntent();
        id = intent.getIntExtra("id", -1);
        Plants plants = null;

        if (id >= 0) {
        //edit plant
            for(Plants p: plantsList){
                if(p.getId() == id){
                    plants = p;
                }
            }
            et_Plant_name.setText(plants.getName());
            et_schedule.setText(plants.getSchedule());
            et_imageUrl.setText(plants.getImageURL());
            tv_plantId.setText(String.valueOf(id));

        }else{
            //create new plant
        }

        btn_ok.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent= new Intent(AddEditOne.this, MainActivity.class);
                startActivity(intent);

                if(id >= 0){
                    Plants updatedPlant = new Plants(id, et_Plant_name.getText().toString(),et_schedule.getText().toString(),et_imageUrl.getText().toString());
                    plantsList.set(id,updatedPlant);

                }else{
                    int nextId = myApplication.getNextId();
                    Plants newPlant = new Plants(nextId, et_Plant_name.getText().toString(), et_schedule.getText().toString(), et_imageUrl.getText().toString());

                    plantsList.add(newPlant);
                    myApplication.setNextId(nextId++);

                }


            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent intent= new Intent(AddEditOne.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}