package com.example.plantcareapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.solver.state.State;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

public class RecycleViewAdapter extends RecyclerView.Adapter<RecycleViewAdapter.MyViewHolder> {
    List<Plants> plantsList;
    Context context;

    public RecycleViewAdapter(List<Plants> plantsList, Context context) {
        this.plantsList = plantsList;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.one_line_plant, parent,false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tv_plantName.setText(plantsList.get(position).getName());
        holder.tv_plantSchedule.setText(plantsList.get(position).getSchedule());
        Glide.with(this.context).load(plantsList.get(position).getImageURL()).into(holder.iv_plantPic);
        holder.parentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, AddEditOne.class);
                intent.putExtra("id", plantsList.get(position).getId());
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return plantsList.size();
    }


    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView iv_plantPic;
        TextView tv_plantName;
        TextView tv_plantSchedule;
        ConstraintLayout parentLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            iv_plantPic = itemView.findViewById(R.id.iv_plantPic);
            tv_plantName = itemView.findViewById(R.id.tv_plantName);
            tv_plantSchedule = itemView.findViewById(R.id.tv_plantSchedule);
            parentLayout = itemView.findViewById(R.id.oneLinePlant);
        }
    }
}


