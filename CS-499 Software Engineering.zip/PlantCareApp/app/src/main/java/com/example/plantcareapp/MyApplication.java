package com.example.plantcareapp;

import android.app.Application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MyApplication extends Application {
    private static List<Plants> plantsList = new ArrayList<Plants>();
    private static int nextId = 5;

    public MyApplication() {
        fillPlantsList();
    }

    private void fillPlantsList() {
        Plants p0 = new Plants(0, "Pothos", "Once a week", "https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1603654968-il_570xN.2485154742_kpa5.jpg?crop=0.856xw:0.955xh;0.0263xw,0.0274xh&resize=768:*" );
        Plants p1 = new Plants(1, "Aglaonema", "Twice a week", "https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1603654887-1427228256-chinese-evergreen-plants-little-water.jpg?crop=0.970xw:0.974xh;0.0208xw,0.0161xh&resize=768:*");
        Plants p2 = new Plants(2, "Jade Plant", "Once a week", "https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1603654852-jade-plant-1589561938.jpg?crop=0.6677678150070788xw:1xh;center,top&resize=768:*");
        Plants p3 = new Plants(3, "Asparagus Fern", "Three times a week", "https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1554477330-beautiful-asparagus-fern-plant-in-a-basket-royalty-free-image-972247932-1546889240.jpg?crop=0.547xw:0.361xh;0.393xw,0.317xh&resize=768:*");
        Plants p4 = new Plants(4, "Chinese Money Plant", "Once a week", "https://hips.hearstapps.com/vader-prod.s3.amazonaws.com/1557177323-pilea-peperomioides-money-plant-in-the-pot-single-royalty-free-image-917778022-1557177295.jpg?crop=1.00xw:0.668xh;0,0.269xh&resize=768:*");

        plantsList.addAll(Arrays.asList( new Plants[] {p0,p1,p2,p3,p4}));


    }

    public static List<Plants> getPlantsList() {
        return plantsList;
    }

    public static void setPlantsList(List<Plants> plantsList) {
        MyApplication.plantsList = plantsList;
    }

    public static int getNextId() {
        return nextId;
    }

    public static void setNextId(int nextId) {
        MyApplication.nextId = nextId;
    }
}
